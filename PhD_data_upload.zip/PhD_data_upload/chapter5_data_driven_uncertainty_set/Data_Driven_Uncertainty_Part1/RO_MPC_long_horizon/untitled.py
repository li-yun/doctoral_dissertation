import numpy as np
import sys
import matplotlib.pyplot as plt
import numpy as np
#from mpl_toolkits.basemap import Basemap
from pandas import DataFrame
import math
import requests

from sklearn import cluster

from sklearn import preprocessing

import alphashape
from shapely.geometry import Polygon, Point, LineString

from sklearn import preprocessing

from descartes import PolygonPatch
import alphashape
import shapely

from sklearn.mixture import GaussianMixture
import matplotlib.patches as patches

import scipy.optimize as so
import os

import time

from sklearn.decomposition import PCA

X_orig = np.load("train_data_raw.npy")
X_train = X_orig[:,0]
plt.plot(X_train)
X_scaled = X_train[:7400].reshape(-1,5)
np.random.shuffle(X_scaled)

def uncertain_set_construct(X, eps = 3, min_samples = 6, k_cluster = 5, plot_fig = True):
    db = cluster.DBSCAN(eps = eps, min_samples = min_samples).fit(X)
    X_clean = X[db.labels_ != -1,:]
    
    outliers = X[db.labels_ == -1,:]
    
    gmm = GaussianMixture(n_components = k_cluster, covariance_type = "full")
    gmm.fit(X_clean)

    if plot_fig:
        plt.figure(figsize = (6,6))
        plt.scatter(X[db.labels_ == -1, 0], X[db.labels_ == -1, 1], 1, c = "k")
        
        plt.scatter(X_clean[:,0],X_clean[:,1], s = 0.1, c = gmm.fit_predict(X_clean), cmap = plt.cm.winter)
        ax = plt.gca()
        ax.set(aspect = "equal",xlim = [-1.5,1.5],ylim = [-1.5,1.5])
    print("outliers is {0:02f}% percent".format((1 - len(X_clean)/len(X))*100))
    
    return gmm, X_clean, outliers






















