import numpy as np
from pyomo.opt import SolverFactory
# import gurobipy

import pandas as pd
import scipy.optimize as so

import matplotlib.pyplot as plt

import pyomo.environ as pyo

import energym
from pyomo.opt import SolverStatus, TerminationCondition

import gurobipy as gp
from gurobipy import GRB

# weather = "CH_VD_Lausanne"
# env = energym.make("SimpleHouseRad-v0", weather=weather, simulation_days=6)

# outputs = env.get_output()
# outputs["temRoo.T"]

# # for generating training data
# steps = 288*5
# out_list = []
# outputs = env.get_output()
# controls = []
# hour = 0
# hours = []
# for i in range(steps):
#     control = {}
#     control['u'] = [0.5*(np.sin(i * 0.1 + np.random.rand()) + 1)]
#     controls +=[ {p:control[p][0] for p in control} ] # each element is a dictionary
#     outputs = env.step(control)
#     _,hour,_,_ = env.get_date()
#     hours.append(hour)
#     out_list.append(outputs)
    
    
# out_df = pd.DataFrame(out_list)
# in_df = pd.DataFrame(controls)



N = 24




# d = np.append(out_df[["TOut.T", "sunRad.y"]].values[:N], np.ones((N,1))*2000, axis = 1)
# d[:,0] -= 273.15
dbar = d.reshape(-1)

###############################################
dim = 2

Ci, Ce, Rie, Reo,  Ai = 9.28479953e+06, 1.00000000e+08, 2.01584186e-03, 1.99362226e-05, 4.85915263e+02

dt = 300
### A's shape is (2,2), B's shape is (2,1), and R's shape is (2,3)
A11 = 1 - dt/(Ci*Rie)
A12 = dt/(Ci*Rie)
A21 = dt/(Ce*Rie)
A22 = 1 - dt/Ce * (1/Rie + 1/Reo)

B1 = dt/Ci*5

R11 = 0
R12 = 0
R21 = dt/(Ce*Reo) ### outdoor temp
R22 = dt/Ce*Ai ### solar irradiation
A = np.array([[A11, A12],
             [A21, A22]])
B = np.array([[B1],
             [0]])
R = np.array([[R11, R12, 0],
             [R21, R22, 0]])



# A = np.array([[0.98834642]])
# B = np.array([[9.17224643e-05]])
# R = np.array([[0.01165358, 0.00012355]])


n = 2
p = 1  ### size of input from grid
q = 1  ### size of input from solar
m = 3  ### size of uncertainty

# N = 24 ### length of prediction horizon

def lifted_matrix(A,B,n,m,N):
    P = np.zeros((n*(N),m*N))
    for i in range(N):
        for j in range(N):
            if j > i:
                Pij = np.zeros((n,m))
            else:
                Pij = np.dot(np.linalg.matrix_power(A,i-j),B)
            P[i*n:(i+1)*n, j*m:(j+1)*m] = Pij
    return P
    
####  X = Fx0 + Fu*u + Fv*v + Fw*d,  d is uncertainty            
def time_lifted_matrix(N):
    Fu = np.zeros((n*N, p*N))
    Fw = np.zeros((n*N, m*N))
    Fv = np.zeros((n*N, q*N))

    Fu = lifted_matrix(A,B,n,p,N)
    Fv = lifted_matrix(A,B,n,q,N)


    Fw = lifted_matrix(A,R,n,m,N)
    
    return Fu, Fv, Fw

Fx = np.zeros((N*n,n))

for t in range(N):
    Fx[t*n:(t+1)*n, :] = np.linalg.matrix_power(A,t+1)


#### Fr and Fv are scaled so that the reference input can be binary ####
Fu, Fv, Fw = time_lifted_matrix(N)

x0 = np.array([21,22]) 
Fx0 = Fx@x0

dbar_diag = np.diag(dbar)


##### indoor temp constraints
Gx = np.kron(np.array([[1],[-1]]), np.kron(np.eye(N),np.array([[1,0]])))

T_high = 24
T_low = 19
gx = np.kron(np.array([T_high, -T_low]), np.ones(N))
##### total input constraints
Gu = np.kron(np.array([[1],[-1]]), np.eye(N))

U_high = 5e4*np.ones(N)### total maximal power input
gu = np.concatenate((U_high*np.ones(N), np.zeros(N)))
##### availability of RES
Gv = np.kron(np.array([[1],[-1]]), np.eye(N))

vbar = 2000*np.ones(N)## availability of local RES  需要修改！！！
gv = np.concatenate((vbar, np.zeros(N)))

trans_mat = -np.kron(np.eye(N), np.array([[0,0,0],[0,1,0],[0,0,1]])) 
dbar_trans = trans_mat@dbar_diag + np.kron(np.eye(N), np.array([[1,0,0],[0,0,0],[0,0,0]]))


#### constraints for AA@x <= qq
AA = -np.eye(N)

qq = np.zeros(N)


####################### temperature constraints #######################
T1 = Gx@Fu
W1 = Gx@Fv
M1 = Gx@Fw@dbar_trans
h1 = gx - Gx@(Fw@dbar + Fx0) ### gx is the upper and lower bounds of indoor temperature

####################### physical constraints of HP ######################
T2 = Gu
W2 = Gv
M2 = np.zeros(shape = (2*N, 3*N))
h2 = gu ### gu is the vector constructed from the upper and lower bounds of total inputs

######################## RES availability constraints #####################
T3 = np.zeros(shape = (2*N,N))
W3 = Gv
M3 = np.concatenate( (np.kron(np.eye(N), np.array([[0,0,1]]))@dbar_diag, np.zeros((N,3*N)) ), axis = 0)  ###np.zeros(shape = (2*N, 3*N))
h3 = gv

T = np.concatenate((T1,T2,T3), axis = 0)
W = np.concatenate((W1,W2,W3), axis = 0)
M = np.concatenate((M1,M2,M3), axis = 0)

h = np.concatenate((h1,h2,h3), axis = 0)

scale = 1
c = scale*np.ones(N) #np.array([])
b = -scale*np.ones(N) #np.array([])


#### classes of different uncertainty set
#pbar = np.array([1,0,0,0]) ##1/kk*np.ones(kk)

uncer_sets = np.load(r"./Data_Driven_Uncertainty/uncer_set.npz")
D_set = uncer_sets["D_set"]
d_set = uncer_sets["d_set"]

for k in range(len(D_set)):
    D_set[k] = np.where(D_set[k]<= 1e-3, 0, D_set[k])
    d_set[k] = np.where(d_set[k] <= 1e-3, 0, d_set[k])


pbar = uncer_sets["pbar"]
kk = len(D_set)
rho = 100
kk = len(D_set)

ind_k = range(kk)
ind_y = range(W.shape[1])
ind_T = range(T.shape[0])
ind_x = range(T.shape[1])
ind_u = range(M.shape[1])


scalar = 1
b = scalar*b
c = scalar*c
