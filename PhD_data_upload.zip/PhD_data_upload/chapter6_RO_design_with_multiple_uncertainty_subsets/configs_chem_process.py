import numpy as np
from pyomo.opt import SolverFactory
# import gurobipy

import pandas as pd
import scipy.optimize as so
from scipy.linalg import block_diag

import matplotlib.pyplot as plt

import pyomo.environ as pyo

#import energym
from pyomo.opt import SolverStatus, TerminationCondition

import gurobipy as gp
from gurobipy import GRB

np.random.seed(12345)

D_set = []
d_set = []

u_set_init = []

process_num = 8
chem_num = 7
period_num = 5
in_num = 2
out_num = 2

mu_demand1 = np.array([300, 450])
mu_demand2 = np.array([350, 320])
mu_demand3 = np.array([200, 100])
mu_demand4 = np.array([250, 250])

var_demand1 = np.array([50, 40])
var_demand2 = np.array([50, 50])
var_demand3 = np.array([30, 40])
var_demand4 = np.array([20, 20])

mu_supply1 = np.array([1200, 1000])
mu_supply2 = np.array([700, 620])
mu_supply3 = np.array([600, 300])
mu_supply4 = np.array([500, 500])

var_supply1 = np.array([100,120])
var_supply2 = np.array([60,60])
var_supply3 = np.array([50,50])
var_supply4 = np.array([20,20])

mu_demand_list = [mu_demand1, mu_demand2, mu_demand3, mu_demand4]
var_demand_list = [var_demand1, var_demand2, var_demand3, var_demand4]

mu_supply_list = [mu_supply1, mu_supply2, mu_supply3, mu_supply4]
var_supply_list = [var_supply1, var_supply2, var_supply3, var_supply4]

set_num = len(mu_demand_list)

### 调整u的取值范围使得算法更容易收敛 ###
u_scale = 10

#for t in range(period_num):
for k in range(set_num):
    mu_supply = mu_supply_list[k]/u_scale
    var_supply = var_supply_list[k]/u_scale
    
    mu_demand = mu_demand_list[k]/u_scale
    var_demand = var_demand_list[k]/u_scale

    ### construct supply uncertainty set
    D_base1 = np.concatenate((np.eye(in_num), -np.eye(in_num)), axis = 0)
    d_base1 = np.concatenate((var_supply+mu_supply, var_supply - mu_supply))

    ### construct demand uncertainty set
    D_base2 = np.concatenate((np.eye(out_num), -np.eye(out_num)), axis = 0)
    d_base2 = np.concatenate((var_demand + mu_demand, var_demand - mu_demand))

    D_base = block_diag(D_base1, D_base2)
    d_base = np.concatenate((d_base1, d_base2))

    
    D = np.kron(np.eye(period_num), D_base)
    d = np.kron(np.ones(period_num), d_base)

    D_set.append(D)
    d_set.append(d)

    u_set_init.append(np.tile(np.concatenate((mu_supply, mu_demand)), period_num))
    #u_set_init.append(np.kron(np.ones(period_num), np.concatenate((mu_supply, mu_demand))))

pbar = np.array([0.5,0.1,0.2,0.2])
#pbar = np.array([0.2,0.2,0.4,0.2])
rho = 0.5
len_D_set = len(D_set)

# for k in range(set_num):
#     mu_supply = mu_supply_list[k]
#     var_supply = var_supply_list[k]
    
#     mu_demand = mu_demand_list[k]
#     var_demand = var_demand_list[k]

#     ### construct supply uncertainty set
#     D_base1 = np.concatenate((np.eye(in_num), -np.eye(in_num)), axis = 0)
#     d_base1 = np.concatenate((var_supply+mu_supply, var_supply - mu_supply))

#     ### construct demand uncertainty set
#     D_base2 = np.concatenate((np.eye(out_num), -np.eye(out_num)), axis = 0)
#     d_base2 = np.concatenate((var_demand + mu_demand, var_demand - mu_demand))

#     D_base = block_diag(D_base1, D_base1)
#     d_base = np.concatenate((d_base1, d_base2))

    
#     D = np.kron(np.eye(period_num), D_base)
#     d = np.kron(np.ones(period_num), d_base)

#     D_set.append(D)
#     d_set.append(d)

#     u_set_init.append(np.kron(np.ones(period_num), np.concatenate((mu_supply, mu_demand))))


c1_base = np.array([10, 10, 10, 10, 10, 10, 10, 10]) ## investment cost for unit expansion amount, alpha_mat
c2_base = np.array([20,20,20,20,20,20,20,20]) ## fixed investment cost for expansino decision, beta_mat

c3_base = np.array([50, 60, 80, 20, 50, 90, 75, 100]) ## operating cost (the amount produced), or called delta
c4_base = np.array([80, 0, 0, 0, 60, 0, 0]) ## purchase cost (the amount purchased), or called tau
nu = -np.array([0, 0, 0, 2200, 0, 0, 1950]) ## sales price

# tau = np.array([550, 0, 0, 0, 567, 0, 0]) ### purchase cost for each raw material
# nu = np.array([0, 0, 0, 1000, 0, 0, 1500]) ### sale price for each product
# delta = np.array([50, 60, 140, 20, 50, 90, 75, 100]) ### unit production cost for each process

# alpha_base = np.array([0,0,0,0,0,0,0,0, 10, 10, 10, 10, 10, 10, 10, 10]) ### expansion cost
# alpha_mat = np.kron(np.eye(period_num), alpha_base)

# beta_base = np.array([50,50,50,50,50,50,50,50, 0,0,0,0,0,0,0,0])  ### expansion cost
# beta_mat = np.kron(np.eye(period_num), beta_base)

c = np.kron(np.ones(period_num), np.concatenate((c1_base,c2_base))) ## c1, c2
b = np.kron(np.ones(period_num), np.concatenate((c3_base,c4_base, nu))) ## v, c3, c4

### add noise to c & b
# c *= 0.1*(np.random.rand(len(c)) - 1)/2
# b *= 0.1*(np.random.rand(len(b)) - 1)/2
c *= (1+0.2*(np.random.rand(len(c)) - 1/2))
b *= (1+0.2*(np.random.rand(len(b)) - 1/2))

scale1 = 0.001 ### original value 0.02
scale2 = 0.001
c *= scale1
b *= scale2
### I: process number, T: time period
### qe: expansion amount, Y: expansion decision, ce: total expansion times, cb: investment budget, Q production capacity, su: market capacity, du: demand
### SA: sell amount, W: operating level

qe_L = np.ones(process_num)*0  # first I (process), then T (time period)
qe_U = np.ones(process_num)*10


CI = 1000*np.ones(period_num)


CI *= scale1

CE = np.array([2,2,2,2,2,2,2,2])   ### largest number of capacity expansion for each process in total


M_Q = np.kron(np.tril(np.ones(period_num), k =0), np.eye(process_num))

### dimension of kappa is (chem_num, process_num)
Kappa = np.array([[0.63, -1, 0, 0, 0, 0, 0],
                 [0.58, -1, 0, 0, 0, 0, 0],
                 [0, 1.25, -4, 0, -1, -1.5, 0],
                 [0, 0.1, -1, 0, 0, 0, 0],
                 [0, 0.8, 0, 0, -1, 0, 0],
                 [0, 0, 2.04, -1, 0, 0, 0],
                 [0, 0, 2.3, -1, 0, 0, 0],
                 [0, 0, 0, 0, 0.93, 0.77, -1]]).T

### first stage decision variables: QE_it, Y_it
### second stage decision variables: W_it, P_jt, SA_it

dim_fs =  int(2*process_num * period_num)                                               # (Y_it, QE_it) dimension of first-stage decision variables
dim_ss =  int((process_num + 2*chem_num)*period_num)                             # (W_it, P_jt, S_jt)dimension of second-stage decision variables

dim_u = (in_num+out_num)*period_num

Q0 = np.array([0,40,80,50,0,30,0,70])/u_scale  ### initial capacity of all processes shape = (process_num,)
#Q0 = np.zeros(process_num)

### qe_L*Y_i <= QE <= qe_U*Y_i, qe_L should be with dimension: (process_num, ), namely the qe_L / qe_U should be the same for different periods
T11 = np.concatenate((-np.diag(qe_U), np.diag(qe_L)), axis = 0)
T12 = np.kron(np.array([[1],[-1]]), np.eye(process_num))
T1_ = np.concatenate((T11, T12), axis = 1)
T1 = np.kron(np.eye(period_num), T1_)
W1 = np.zeros((2*process_num*period_num, dim_ss))
M1 = np.zeros((2*process_num*period_num, dim_u))
h1 = np.zeros(2*process_num*period_num)

### sum_t(Y_it) <= ce_i , dimension of CE should be (process_num,) 
_T2 = np.concatenate((np.eye(process_num), np.zeros((process_num, process_num))), axis = 1)
T2 = np.kron(np.ones((1, period_num)), _T2)

W2 = np.zeros((process_num, dim_ss))
M2 = np.zeros((process_num, dim_u))
h2 = CE

### (c1_it*QE_it + c2_it*Y_it <= ci_it): investment budget constraints: beta and alpha dimensions should be (process_num,), dimension of CI should be (period_num,)
# _T3 = np.concatenate((c2_base, c1_base))
# T3 = np.kron(np.eye(period_num), _T3)
T3_blocks = [row.reshape(1, -1) for row in c.reshape(period_num, -1)]
T3 = block_diag(*T3_blocks)

W3 = np.zeros((period_num, dim_ss))
M3 = np.zeros((period_num, dim_u))
h3 = CI

### W_sit <= Q_it
_T4 = np.concatenate((np.zeros((process_num,process_num)), np.eye(process_num)), axis = 1)
T4 = -np.kron(np.tril(np.ones(period_num), k = 0), _T4)

W4 = np.kron(np.eye(period_num), np.concatenate( (np.eye(process_num), np.zeros((process_num, 2*chem_num))), axis =1))
M4 = np.zeros((period_num*process_num, dim_u))
h4 = np.kron(np.ones(period_num), Q0)   ### Q0 defines the initial capacity of the each process

### P_it - sum(kappa_ij*W_it) -S_jt = 0， Kappa --> (chem_num, process_num), !!! equality constraint
T5 = np.zeros((2*period_num*chem_num, dim_fs))
_W51 = np.concatenate((-Kappa, np.eye(chem_num), -np.eye(chem_num)), axis =1 )
W51 = np.kron(np.eye(period_num), _W51)
W52 = -W51
W5 = np.concatenate((W51,W52), axis = 0)
M5 = np.zeros((2*period_num*chem_num, dim_u))
h5 = np.zeros(2*period_num*chem_num)

### P_jt <= su_jt
# W6_ = np.concatenate( (np.zeros((chem_num, process_num)), np.eye(chem_num), 0*np.eye(chem_num)), axis = 1 )
# W6 = np.kron(np.eye(period_num), W6_)

# mat_chem_in = np.array([[1,0,0,0],
#                            [0,0,0,0],
#                            [0,0,0,0],
#                            [0,0,0,0],
#                            [0,1,0,0],
#                            [0,0,0,0],
#                            [0,0,0,0]])
# mat_chem_out =  = np.array([[0,0,0,0],
#                            [0,0,0,0],
#                            [0,0,0,0],
#                            [0,0,1,0],
#                            [0,0,0,0],
#                            [0,0,0,0],
#                            [0,0,0,1]])

# mat_chem_in = np.array([[1,0,0,0,0,0,0],
#                        [0,0,0,0,1,0,0]])

# mat_chem_out = np.array([[0,0,0,1,0,0,0],
#                         [0,0,0,0,0,0,1]])
# assert mat_chem_in.shape == mat_chem_out.shape


# T6 = np.zeros((in_num*period_num, dim_fs))
# _W6 = np.concatenate((np.zeros((in_num, process_num)), mat_chem_in, np.zeros((in_num, chem_num))), axis = 1)
# W6 = np.kron(np.eye(period_num), _W6)

# _M6 = np.concatenate((np.eye(in_num), np.zeros((in_num, out_num))), axis = 1)
# M6 = -np.kron(np.eye(period_num), _M6)

# h6 = np.zeros(in_num*period_num)

### constraints for limiting the purchase of non-raw material. 
T6 = np.zeros((chem_num*period_num, dim_fs))
_W6 = np.concatenate((np.zeros((chem_num, process_num)), np.eye(chem_num), np.zeros((chem_num, chem_num))), axis = 1)
W6 = np.kron(np.eye(period_num), _W6)

_M6 = np.array([[1,0,0,0],
                [0,0,0,0],
                [0,0,0,0],
                [0,0,0,0],
                [0,1,0,0],
                [0,0,0,0],
                [0,0,0,0]])
M6 = -np.kron(np.eye(period_num), _M6)
h6 = np.zeros((chem_num*period_num))


### S_jt <= du_jt
# T7 = np.zeros((out_num*period_num, dim_fs))
# _W7 = np.concatenate( (np.zeros((out_num, process_num)), np.zeros((out_num, chem_num)), mat_chem_out), axis = 1)
# W7 = np.kron(np.eye(period_num), _W7)
# _M7 = np.concatenate((np.zeros((out_num, in_num)), np.eye(out_num)), axis = 1)
# M7 = -np.kron( np.eye(period_num), _M7 )

# h7 = np.zeros(out_num*period_num) 
T7 = np.zeros((chem_num*period_num, dim_fs))
_W7 = np.concatenate((np.zeros((chem_num, process_num)), np.zeros((chem_num, chem_num)), np.eye(chem_num)), axis =1)
W7 = np.kron(np.eye(period_num), _W7)
_M7 = np.array([[0,0,0,0],
               [0,0,0,0],
               [0,0,0,0],
               [0,0,1,0],
               [0,0,0,0],
               [0,0,0,0],
               [0,0,0,1]])
M7 = -np.kron(np.eye(period_num), _M7)
h7 = np.zeros(chem_num*period_num)

### QE_it >= 0
T8 = -np.kron( np.eye(period_num), np.concatenate(( np.zeros((process_num, process_num)), np.eye(process_num)), axis = 1))
W8 = np.zeros((process_num*period_num, dim_ss))
M8 = np.zeros((process_num*period_num, dim_u))
h8 = np.zeros(process_num*period_num)

### W, P, S >= 0
T9 = np.zeros((dim_ss, dim_fs))
W9 = - np.eye(dim_ss)
M9 = np.zeros((dim_ss, dim_u))
h9 = np.zeros(dim_ss)

T = np.concatenate((T4,T5,T6,T7,T9), axis = 0)

W = np.concatenate((W4,W5,W6,W7,W9), axis = 0)

M = np.concatenate((M4,M5,M6,M7,M9), axis = 0)

h = np.concatenate((h4,h5,h6,h7,h9))


AA = np.concatenate((T1,T2,T3,T8), axis = 0)
qq = np.concatenate((h1,h2,h3,h8))



ind_k = range(len_D_set)
ind_y = range(W.shape[1])
ind_T = range(T.shape[0])
ind_x = range(T.shape[1])
ind_u = range(M.shape[1])


assert W.shape[0] == T.shape[0]

x_type = []
for k in range(period_num):
    for t in range(process_num*2):
        if t < process_num:
            x_type.append(GRB.BINARY)
        else:
            x_type.append(GRB.CONTINUOUS)


















