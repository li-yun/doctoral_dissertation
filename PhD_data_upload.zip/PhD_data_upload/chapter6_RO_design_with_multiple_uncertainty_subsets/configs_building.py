import numpy as np
import pandas as pd
import scipy.optimize as so
from scipy.linalg import block_diag
import matplotlib.pyplot as plt
import gurobipy as gp
from gurobipy import GRB
from itertools import product
from scipy.linalg import block_diag

######### generate constraints matrixes ##########
### x_t+1 = A*x_t + B_u*u_t + B_v*v_t + B_w*w_t
### u: heating input, v_t: predicted ambient temperature & underground temperature, w_t prediction error of ambient temperature
N = 10


A = np.array([[0.0167, 0.0048, 0.1245, 0.1409],
             [0.0005, 0.0002, 0.0039, 0.0044],
             [0.0253, 0.0073, 0.3321, 0.0617],
             [0.0244, 0.0070, 0.0526, 0.3456]])

Bu = np.array([[0.0986],
              [0.0029],
              [0.0288],
              [0.0275]])

Bw = np.array([[0.2536],
              [0.0070],
              [0.4450],
              [0.4477]])

Bv1 = np.array([[0.2536],
              [0.0070],
              [0.4450],
              [0.4477]])

Bv2 = np.array([[0.4596],
               [0.9840],
               [0.1287],
               [0.1225]])

Bv = np.array([[0.2536, 0.4596],
              [0.0070, 0.9840],
              [0.4450, 0.1287],
              [0.4477, 0.1225]])

n = 4
p = 1  ### heating input
m = 1  ### uncertainty input
q = 2  ### external input



def lifted_matrix(A,B,n,m,N):
    P = np.zeros((n*(N),m*N))
    for i in range(N):
        for j in range(N):
            if j > i:
                Pij = np.zeros((n,m))
            else:
                Pij = np.dot(np.linalg.matrix_power(A,i-j),B)
            P[i*n:(i+1)*n, j*m:(j+1)*m] = Pij
    return P
    
####  X = Fx0 + Fu*u + Fv*v + Fw*d,  d is uncertainty            
def time_lifted_matrix(N):
    Fu = np.zeros((n*N, p*N)) ### heating input matrix
    Fw = np.zeros((n*N, m*N)) ### uncertainty input matrix
    Fv = np.zeros((n*N, q*N)) ### external input matrix

    Fu = lifted_matrix(A,Bu,n,p,N)
    Fv1 = lifted_matrix(A,Bv1,n,1,N)
    Fv2 = lifted_matrix(A,Bv2,n,1,N)
    Fw = lifted_matrix(A,Bw,n,m,N)
    
    return Fu, Fv1, Fv2, Fw



### load ambient temperature data ###
df_knmi_2023 = pd.read_csv("./knmi_2023.csv")
T_out = df_knmi_2023.loc[:,"T"].values
T_ground = np.mean(T_out)

### Tx + Wy + Mu <= h

day = 100
T_low_base = np.array([15,15,15,15,15,15,15,21,21,21,21,21,21,21,21,21,21,21,15,15,15,15,15,15])
T_low = np.array([T_low_base for _ in range(day)])
T_low = T_low.reshape(-1)


def generate_necessary_data(N):
    Fu, Fv1, Fv2, Fw = time_lifted_matrix(N)
    
    Fx = np.zeros((N*n,n))
    for t in range(N):
        Fx[t*n:(t+1)*n, :] = np.linalg.matrix_power(A,t+1)
        
    Gx = np.kron(-np.eye(N), np.array([[1,0,0,0]]))
    
    ####################### temperature constraints #######################
    _W1 = Gx@Fu
    T1 = _W1[:,0].reshape(-1,1)
    W1 = _W1[:,1:]
    M1 = Gx@Fw  ### w_vec: vector of disturbance
    
    ####################### physical constraints of HP ######################
    
    len_y = N-1
    
    assert W1.shape[1] == len_y
    ##### total input constraints
    Gu = np.kron(np.array([[1],[-1]]), np.eye(len_y))
    
    U_high = 150### total maximal power input
    gu = np.concatenate((U_high*np.ones(len_y), np.zeros(len_y)))
    
    T2 = np.zeros((2*len_y,1))
    W2 = Gu
    M2 = np.zeros(shape = (2*len_y, N))
    h2 = gu ### gu is the vector constructed from the upper and lower bounds of total inputs
    
    T = np.concatenate((T1,T2), axis = 0)
    W = np.concatenate((W1,W2), axis = 0)
    M = np.concatenate((M1,M2), axis = 0)


    b = np.ones(N)
    
    x0 = np.array([22,22,22,22])
    cost = 0
    
    t = 0
    v1_vec = T_out[t:t+N]
    v2_vec = T_ground * np.ones(N)
    
    Fx0 = Fx@x0
    
    #gx = np.concatenate((T_high[t:t+N],-T_low[t:t+N]))
    gx = -T_low[t:t+N]
    h1 = gx - Gx@(Fv1@v1_vec + Fv2@v2_vec + Fx0) ### gx is the upper and lower bounds of indoor temperature
    h = np.concatenate((h1,h2))
    
    c = np.array([1])
    b = np.ones(len_y)

    AA = np.array([[1],
               [-1]])
    qq = np.array([U_high, 0])

    return T, W, M, AA, qq, c, b, h



### construct uncertainty set list
D1 = np.array([[1],
              [-1]])
D2 = np.array([[1],
              [-1]])
d1 = np.array([2,0])
d2 = np.array([0,2])
D_set = [D1, D2]
d_set = [d1, d2]


T, W, M, AA, qq, c, b, h = generate_necessary_data(N)

ind_ut = range(1)
idx_t = range(N)
ind_k = range(len(D_set))
ind_x = range(T.shape[1])
ind_y = range(W.shape[1])
ind_u = range(M.shape[1])
ind_T = range(T.shape[0])

x_type = GRB.CONTINUOUS

def generate_D_d_stacked(N):
    D_set_stacked = []
    d_set_stacked = []
    ind_k_stacked = 0
    ranges = [range(2)] * N  # Create N ranges of length 5
    for values in product(*ranges):
        D_set_mid = []
        d_set_mid = np.array([])
        for k in iter(values):
            D_set_mid.append(D_set[k])
            d_set_mid = np.append(d_set_mid, d_set[k])
        D_set_stacked.append(block_diag(*D_set_mid))
        d_set_stacked.append(d_set_mid)

    return D_set_stacked, d_set_stacked

    
ind_ut = range(1)
idx_t = range(N)
ind_k = range(len(D_set))
ind_x = range(T.shape[1])
ind_y = range(W.shape[1])
ind_u = range(M.shape[1])
ind_T = range(T.shape[0])


